import Login from './components/Login';

function App() {
  return (
    <div>
      <h1>App Component Loaded</h1>
      <Login />
    </div>
  );
}

export default App;
